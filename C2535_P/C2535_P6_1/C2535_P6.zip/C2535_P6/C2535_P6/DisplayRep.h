//Kim Lien Chu
//COP2535.0M1
#ifndef DISPLAYREP_H
#define DISPLAYREP_H

#include <iostream>
#include <sstream>
#include <stack>
#include <string>

using namespace std;

/*******************************************
class DisplayRep
display report header
* *********************************************************/
class DisplayRep
{
private:


public:
	DisplayRep(){};     // default constructor

	void displayHeader();
	~DisplayRep(){};		// destructor


};

#endif
